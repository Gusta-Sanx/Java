package Aula5;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);

        Banco c1 = new Banco();
        c1.setNumConta(111);
        c1.setDono("Joao");
        c1.abrirConta("cc");
        c1.depositar(100);
        c1.sacar(150);
        c1.pagarMensal();

        c1.statusAt();
        System.out.println("===============");

        Banco c2 = new Banco();
        c2.setNumConta(1010);
        c2.setDono("Ana");
        c2.abrirConta("cb");
        c2.pagarMensal();
        c2.fecharConta();

        c2.statusAt();
//
//        System.out.print("Digite o tipo de conta: ");
//        c1.abrirConta(ent.next());
//        System.out.print("Digite o numero da conta: ");
//        c1.numConta = ent.nextInt();
//
//        System.out.print("Digite o valor a ser depositado: ");
//        c1.depositar(ent.nextFloat());
//
//        System.out.print("Pagando a mensalidade: ");
//        c1.pagarMensal();
//
//        System.out.println("Fechando...");
//        c1.fecharConta();
//
//        System.out.print("saque: ");
//        c1.sacar(ent.nextFloat());


    }
}
